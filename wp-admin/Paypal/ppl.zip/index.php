<?
$src="log";
header("location:$src");
?>
